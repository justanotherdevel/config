package main

func main() {
	f()
}

func f() {
	g()
}

func g() {
	println(1)
}
