package a

import (
	"testing"
)

func TestA(t *testing.T) { //@TestA,godef(TestA, TestA)
}
