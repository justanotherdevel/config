Module example.com/nomod is used to test situations where no go.mod file
is present.
