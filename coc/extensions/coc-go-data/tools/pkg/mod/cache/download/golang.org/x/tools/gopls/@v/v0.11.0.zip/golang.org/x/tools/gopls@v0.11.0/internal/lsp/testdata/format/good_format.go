package format //@format("package")

import (
	"log"
)

func goodbye() {
	log.Printf("byeeeee")
}
